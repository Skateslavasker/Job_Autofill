(async () => {
    try {
        const response = await fetch("https://localhost:5000/profile");
        const data = await response.json();
        console.log("Fetched profile data", data);

        // Sprint 3 - Implemnentation
    } catch( error) {
        console.error("Error fetching profile data", error);

    }
})();